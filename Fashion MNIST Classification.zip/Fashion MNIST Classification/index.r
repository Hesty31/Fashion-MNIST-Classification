library(keras)
library(tensorflow)
install_tensorflow()

dataset <- dataset_fashion_mnist()
train_images <- dataset$train$x
train_labels <- dataset$train$y

model <- keras_model_sequential() %>%
  layer_conv_2d(filters = 32, kernel_size = c(3,3), activation = 'relu', input_shape = c(28, 28, 1)) %>%
  layer_max_pooling_2d(pool_size = c(2, 2)) %>%
  layer_conv_2d(filters = 64, kernel_size = c(3,3), activation = 'relu') %>%
  layer_max_pooling_2d(pool_size = c(2, 2)) %>%
  layer_conv_2d(filters = 64, kernel_size = c(3,3), activation = 'relu') %>%
  layer_flatten() %>%
  layer_dense(units = 64, activation = 'relu') %>%
  layer_dense(units = 10, activation = 'softmax')

model %>% compile(
  optimizer = 'adam',
  loss = 'sparse_categorical_crossentropy',
  metrics = 'accuracy'
)

model %>% fit(train_images, train_labels, epochs = 5)

test_images <- array_reshape(test_images, c(nrow(test_images), 28, 28, 1))
predictions <- model %>% predict(test_images[1:2, , , ])
print(predictions)